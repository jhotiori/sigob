package org.javapi.sigob.cli;

import jakarta.persistence.EntityManager;
import org.javapi.sigob.config.JPAConfig;
import org.javapi.sigob.repository.VendaRepository;
import org.javapi.sigob.service.VendaService;

public class MenuVendas extends Menu{

    public MenuVendas(){
        this.title = "Operações de Venda";
        addEntry("Listar vendas", this::listarVendas);
        addEntry("Iniciar nova venda", this::listarVendas);
    }

    private VendaService getService(EntityManager em) {
        return new VendaService(new VendaRepository(em));
    }

    private void listarVendas() {
        EntityManager em = JPAConfig.getEntityManager();

        try {

        } finally {
            em.close;
        }
    }
}
